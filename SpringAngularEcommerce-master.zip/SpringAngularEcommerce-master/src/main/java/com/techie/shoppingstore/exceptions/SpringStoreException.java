package com.techie.shoppingstore.exceptions;

public class SpringStoreException extends RuntimeException {
    public SpringStoreException(String message) {
        super(message);
    }
}
