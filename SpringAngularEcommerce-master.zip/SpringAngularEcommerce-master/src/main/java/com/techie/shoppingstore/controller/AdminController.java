package com.techie.shoppingstore.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {


}
